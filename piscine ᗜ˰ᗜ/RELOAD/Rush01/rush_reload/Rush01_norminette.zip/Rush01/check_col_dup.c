/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check_col_dup.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alexoi <alexoi@student.42kl.edu.my>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/21 11:50:07 by alexoi            #+#    #+#             */
/*   Updated: 2026/06/21 11:52:54 by alexoi           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	check_col_dup(int grid[4][4], int row)
{
	int	col;
	int	prev_row;

	col = 0;
	while (col < 4)
	{
		prev_row = 0;
		while (prev_row < row)
		{
			if (grid[row][col] == grid[prev_row][col])
				return (0);
			prev_row++;
		}
		col++;
	}
	return (1);
}
