/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alexoi <alexoi@student.42kl.edu.my>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/21 09:47:26 by alexoi            #+#    #+#             */
/*   Updated: 2026/06/21 17:53:30 by jihor            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int		ft_atoi_clues(char *str, int *clues);
void	print_grid(int grid[4][4]);
void	get_a_perm(int index, int *row_dest);
int		check_col_dup(int grid[4][4], int row);
int		count_visible(int line[4]);
int		check_top(int grid[4][4], int col, int expected);
int		check_bottom(int grid[4][4], int col, int expected);
int		check_left(int grid[4][4], int row, int expected);
int		check_right(int grid[4][4], int row, int expected);
int		check_all_cols(int grid[4][4], int clues[16]);
int		solve(int grid[4][4], int row, int clues[16]);

int	main(int argc, char **argv)
{
	int	grid[4][4];
	int	clues[16];

	if (argc != 2)
	{
		write(1, "Error\n", 6);
		return (0);
	}
	if (!ft_atoi_clues(argv[1], clues))
	{
		write(1, "Error\n", 6);
		return (0);
	}
	if (solve(grid, 0, clues))
		print_grid(grid);
	else
		write(1, "Error\n", 6);
	return (0);
}
