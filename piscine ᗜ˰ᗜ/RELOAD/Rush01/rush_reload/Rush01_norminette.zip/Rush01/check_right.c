/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check_right.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alexoi <alexoi@student.42kl.edu.my>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/21 15:21:40 by alexoi            #+#    #+#             */
/*   Updated: 2026/06/21 16:30:50 by jihor            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	count_visible(int line[4]);

int	check_right(int grid[4][4], int row, int expected)
{
	int	temp[4];
	int	i;

	i = 0;
	while (i < 4)
	{
		temp[i] = grid[row][3 - i];
		i++;
	}
	return (count_visible(temp) == expected);
}
