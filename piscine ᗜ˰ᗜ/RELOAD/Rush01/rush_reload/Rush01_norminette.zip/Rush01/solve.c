/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   solve.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alexoi <alexoi@student.42kl.edu.my>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/21 15:51:41 by alexoi            #+#    #+#             */
/*   Updated: 2026/06/21 17:54:10 by jihor            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		check_all_cols(int grid[4][4], int clues[16]);
void	get_a_perm(int index, int *row_dest);
int		check_left(int grid[4][4], int row, int expected);
int		check_right(int grid[4][4], int row, int expected);
int		check_col_dup(int grid[4][4], int row);

int	solve(int grid[4][4], int row, int clues[16])
{
	int	i;

	i = 0;
	if (row == 4)
		return (check_all_cols(grid, clues));
	while (i < 24)
	{
		get_a_perm(i, grid[row]);
		if (check_left(grid, row, clues[row + 8])
			&& check_right(grid, row, clues[row + 12]))
		{
			if (check_col_dup(grid, row))
			{
				if (solve(grid, row + 1, clues))
					return (1);
			}
		}
		i++;
	}
	return (0);
}
