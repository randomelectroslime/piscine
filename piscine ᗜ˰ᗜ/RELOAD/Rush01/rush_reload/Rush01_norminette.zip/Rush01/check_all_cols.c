/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check_all_cols.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alexoi <alexoi@student.42kl.edu.my>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/21 15:39:39 by alexoi            #+#    #+#             */
/*   Updated: 2026/06/21 16:34:45 by jihor            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	check_top(int grid[4][4], int col, int expected);
int	check_bottom(int grid[4][4], int col, int expected);

int	check_all_cols(int grid[4][4], int clues[16])
{
	int	i;

	i = 0;
	while (i < 4)
	{
		if (!check_top(grid, i, clues[i]))
			return (0);
		if (!check_bottom(grid, i, clues[i + 4]))
			return (0);
		i++;
	}
	return (1);
}
