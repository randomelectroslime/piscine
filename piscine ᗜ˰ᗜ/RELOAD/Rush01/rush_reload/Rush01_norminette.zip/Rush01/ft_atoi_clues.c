/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi_clues.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alexoi <alexoi@student.42kl.edu.my>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/21 11:14:57 by alexoi            #+#    #+#             */
/*   Updated: 2026/06/21 14:34:57 by alexoi           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_atoi_clues(char *str, int *clues)
{
	int	i;

	i = 0;
	while (*str != '\0')
	{
		if (*str == ' ')
			str++;
		else if (*str >= '1' && *str <= '4')
		{
			if (i >= 16)
				return (0);
			clues[i] = *str - '0';
			i++;
			str++;
		}
		else
			return (0);
	}
	return (i == 16);
}
