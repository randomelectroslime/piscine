/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check_top.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alexoi <alexoi@student.42kl.edu.my>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/21 15:09:32 by alexoi            #+#    #+#             */
/*   Updated: 2026/06/21 16:33:09 by jihor            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	count_visible(int line[4]);

int	check_top(int grid[4][4], int col, int expected)
{
	int	temp[4];
	int	i;

	i = 0;
	while (i < 4)
	{
		temp[i] = grid[i][col];
		i++;
	}
	return (count_visible(temp) == expected);
}
